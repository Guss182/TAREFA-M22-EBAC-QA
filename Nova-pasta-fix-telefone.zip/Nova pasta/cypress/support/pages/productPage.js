class ProductPage {
  openShop() {
    cy.visit('/produtos/');
    cy.get('div.products, ul.products, div.products.products-grid', { timeout: 20000 })
      .should('be.visible');
  }

  openFirstProductFromGrid() {
    cy.get('a[href*="/product/"]', { timeout: 20000 })
      .filter(':visible')
      .first()
      .click();

    cy.location('pathname', { timeout: 20000 }).should('include', '/product/');
  }

  selectAnyVariations() {
    cy.get('body').then(($body) => {
      const hasVariationsForm = $body.find('form.variations_form').length > 0;
      const hasAttributeSelect = $body.find('select[name^="attribute_"]').length > 0;
      if (!hasVariationsForm || !hasAttributeSelect) return;

      cy.get('form.variations_form', { timeout: 20000 }).within(() => {
        cy.get('select[name^="attribute_"]', { timeout: 20000 }).each(($sel) => {
          cy.wrap($sel)
            .find('option')
            .then(($opts) => {
              const values = [...$opts]
                .map((o) => o.getAttribute('value'))
                .filter((v) => v && v.trim() !== '');

              if (!values.length) return;

              cy.wrap($sel)
                .select(values[0], { force: true })
                .trigger('change', { force: true });
            });
        });
      });
    });

    cy.get('input.variation_id', { timeout: 20000 }).should(($el) => {
      const v = $el.val();
      expect(v, 'variation_id preenchido').to.not.be.oneOf(['', '0', null, undefined]);
    });
  }

  setQuantity(qty = 1) {
    cy.get('input.qty, input[name="quantity"]', { timeout: 20000 })
      .first()
      .clear({ force: true })
      .type(String(qty), { force: true });
  }

  addToCart() {
    cy.get(
      'button.single_add_to_cart_button, button[name="add-to-cart"], .single_add_to_cart_button',
      { timeout: 20000 }
    )
      .filter(':visible')
      .should('not.have.class', 'disabled')
      .click({ force: true });
  }

  goToCartFromNotice() {
    cy.contains('a', /ver carrinho|view cart/i, { timeout: 20000 }).click({ force: true });
    cy.location('pathname', { timeout: 20000 }).should('include', '/carrinho');
  }
}

module.exports = new ProductPage();
