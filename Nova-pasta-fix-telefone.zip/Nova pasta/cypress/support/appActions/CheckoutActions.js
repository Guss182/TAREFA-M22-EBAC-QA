const productPage = require('../pages/productPage');
const cartPage = require('../pages/cartPage');
const checkoutPage = require('../pages/checkoutPage');

class CheckoutActions {
  buyRandomProductAndCheckout(billing, quantity = 1) {
    productPage.openShop();
    productPage.openFirstProductFromGrid();
    productPage.selectAnyVariations();
    productPage.setQuantity(quantity);
    productPage.addToCart();
    productPage.goToCartFromNotice();
    cartPage.proceedToCheckout();
    checkoutPage.fillBilling(billing);
    checkoutPage.placeOrder();
    checkoutPage.assertOrderReceived();
  }
}

module.exports = new CheckoutActions();