/// <reference types="cypress" />

describe('M23 - Intercept WooCommerce (fragments)', () => {
  // “cara de aula”: helper simples dentro do spec (não é command)
  const interceptFragments = (alias = 'fragments') => {
    cy.intercept('POST', /wc-ajax=get_refreshed_fragments/i).as(alias);
  };

  const assertFragments = (i) => {
    expect(i.response?.statusCode).to.eq(200);
    expect(i.response?.body).to.have.property('fragments');
    expect(i.response?.body).to.have.property('cart_hash');
  };

  const openFirstProduct = () => {
    // com baseUrl configurado, navegamos por caminho relativo (como na aula)
    cy.visit('/produtos/');

    // garante que a grade de produtos carregou
    cy.get('div.products, ul.products, .products', { timeout: 20000 }).should('be.visible');

    // selector resiliente (o tema pode trocar a classe do link do card)
    cy.get(
      'a.woocommerce-LoopProduct-link, a.woocommerce-loop-product__link, a[href*="/product/"], a[href*="/produto/"]',
      { timeout: 20000 }
    )
      .filter(':visible')
      .first()
      .click({ force: true });

    // confirma que saiu da listagem e entrou em um produto
    cy.location('pathname', { timeout: 20000 }).should('match', /\/(product|produto)\//);
  };

  const selectVariationsIfNeeded = () => {
    cy.get('body').then(($b) => {
      if (!$b.find('form.variations_form').length) return;

      // tenta selects (mais “aula” e simples)
      cy.get('form.variations_form select').each(($sel) => {
        cy.wrap($sel).find('option').then(($opts) => {
          const opt = [...$opts].find((o) => o.value && o.value !== '');
          if (opt) cy.wrap($sel).select(opt.value, { force: true });
        });
      });

      // garante variation_id preenchido
      cy.get('input.variation_id', { timeout: 20000 })
      // espera o Woo preencher o id da variação selecionada
      .should(($input) => {
        const v = $input.val()
        // v pode ser string ou number - validamos que virou um número > 0
        expect(v, 'variation_id preenchido').to.exist
        const s = String(v).trim()
        expect(s, 'variation_id não vazio').to.not.be.oneOf(['', '0', 'null', 'undefined'])
        expect(s, 'variation_id numérico').to.match(/^\d+$/)
      });
    });
  };

  const addToCart = (alias) => {
    interceptFragments(alias);

    openFirstProduct();
    selectVariationsIfNeeded();

    cy.get('button.single_add_to_cart_button, button[name="add-to-cart"]', { timeout: 20000 })
      .should('be.enabled')
      .click({ force: true });

    cy.wait(`@${alias}`, { timeout: 20000 }).then(assertFragments);
  };

  const goToCart = () => {
    cy.get('a.wc-forward, a.cart-contents, a[href*="/carrinho"]', { timeout: 20000 })
      .filter(':visible')
      .first()
      .click();
    cy.location('pathname', { timeout: 20000 }).should('include', '/carrinho');
  };

  it('ADD: valida fragments ao adicionar item', () => {
    addToCart('frAdd');
    cy.get('.woocommerce-message, .woocommerce-notices-wrapper').should('be.visible');
  });

  it('UPDATE: valida fragments ao atualizar quantidade', () => {
    addToCart('frAdd');
    goToCart();

    interceptFragments('frUpdate');

    cy.get('input.qty', { timeout: 20000 })
      .first()
      .clear({ force: true })
      .type('2', { force: true })
      .should('have.value', '2');

    // Nem todo tema do WooCommerce exibe o botão "update_cart" da mesma forma.
    // Alguns usam <button>, outros <input>, e alguns fazem update automático via change/blur.
    cy.get('body').then(($body) => {
      const hasBtn = $body.find('button[name="update_cart"]').length;
      const hasInput = $body.find('input[name="update_cart"]').length;

      if (hasBtn) {
        cy.get('button[name="update_cart"]', { timeout: 20000 }).click({ force: true });
        return;
      }

      if (hasInput) {
        cy.get('input[name="update_cart"]', { timeout: 20000 }).click({ force: true });
        return;
      }

      // fallback: tenta botão por texto (PT/EN) ou dispara change/blur para update automático
      const byText = $body.find('button').filter((_, el) => {
        const t = (el.innerText || '').toLowerCase();
        return t.includes('atualizar') || t.includes('update');
      });

      if (byText.length) {
        cy.wrap(byText.first()).click({ force: true });
        return;
      }

      cy.get('input.qty').first().trigger('change', { force: true }).blur({ force: true });
    });

    cy.wait('@frUpdate', { timeout: 20000 }).then(assertFragments);
});

  it('REMOVE: valida fragments ao remover item', () => {
    addToCart('frAdd');
    goToCart();

    interceptFragments('frRemove');

    cy.get('a.remove', { timeout: 20000 }).first().click({ force: true });

    cy.wait('@frRemove', { timeout: 20000 }).then(assertFragments);
  });

  it('STUB: simula a resposta de fragments e valida o body', () => {
    const stubbed = {
      fragments: {
        'div.widget_shopping_cart_content': '<div><p>Stub Cart</p></div>',
      },
      cart_hash: 'stub_123',
    };

    cy.intercept('POST', /wc-ajax=get_refreshed_fragments/i, {
      statusCode: 200,
      body: stubbed,
    }).as('frStub');

    openFirstProduct();
    selectVariationsIfNeeded();

    cy.get('button.single_add_to_cart_button, button[name="add-to-cart"]', { timeout: 20000 })
      .click({ force: true });

    cy.wait('@frStub').then((i) => {
      expect(i.response.body).to.deep.eq(stubbed);
    });
  });
});