/// <reference types="cypress" />

const { faker } = require('@faker-js/faker');

const loginPage = require('../support/pages/loginPage');
const checkoutActions = require('../support/appActions/CheckoutActions');

describe('Checkout (Actions) - V1', () => {
  it('deve finalizar compra usando Actions', () => {
    const user = {
      email: '123@123.com',
      senha: '1234@abcd',
      remember: false,
    };

    const quantity = faker.number.int({ min: 1, max: 3 });

    const billing = {
      firstName: faker.person.firstName(),
      lastName: faker.person.lastName(),
      address1: faker.location.streetAddress(),
      city: faker.location.city(),
      postcode: faker.location.zipCode('########'),
      // O checkout do WooCommerce normalmente valida telefone com DDD.
      // Mantemos APENAS números e com 11 dígitos (ex: 11 + 9 dígitos) para evitar erro de validação.
      phone: faker.phone.number('11#########'),
      // pode ser diferente do login; aqui é só o e-mail de cobrança
      email: faker.internet.email().toLowerCase(),
    };

    loginPage.visit();
    loginPage.login(user);
    checkoutActions.buyRandomProductAndCheckout(billing, quantity);
  });
});